﻿using System;

namespace string730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;

            int c = a + b;
            Console.WriteLine(c);

            string firstName = "Brain";
            string lastName = "Mentors";

            Console.WriteLine("Length of the firstName string:"+firstName.Length);
            Console.WriteLine("Length of the firstName string:"+lastName.Length);

            Console.WriteLine("Normal Case to Upper Case:"+firstName.ToUpper());
            Console.WriteLine("Normal Case to Lower Case:"+firstName.ToLower());

            //string name = firstName + lastName; // + = Concatenation/Joining
            //Console.WriteLine(name);
            //Console.WriteLine(firstName+lastName);

            //String Concatenation function
            //Console.WriteLine(string.Concat(firstName, lastName));
            //String Interpolation
            string name = $"Name is: {firstName} {lastName}";
            Console.WriteLine(name);
        }
    }
}
