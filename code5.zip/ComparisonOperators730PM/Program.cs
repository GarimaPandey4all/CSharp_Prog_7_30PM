﻿using System;

namespace ComparisonOperators730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            // ==, !=, > , <, >=, <=

            if(a == b)
            Console.WriteLine("a == b");

            if(a != b)
            Console.WriteLine("a != b");

            if(a >= b)
            Console.WriteLine("a >= b");

            if(a <= b)
            Console.WriteLine("a <= b");
        }
    }
}
