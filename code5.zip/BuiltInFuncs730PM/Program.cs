﻿using System;

namespace BuiltInFuncs730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Maximum Value is:"+(Math.Max(a, b)));

            Console.WriteLine("Minimum Value is:"+(Math.Min(a, b)));

            Console.WriteLine("Square root is:"+(Math.Sqrt(9)));

            Console.WriteLine("Round value is:"+(Math.Round(9.10)));

            Console.WriteLine("Absolute value is:"+(Math.Abs(-5.9)));
        }
    }
}
