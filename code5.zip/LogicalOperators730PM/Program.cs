﻿using System;

namespace LogicalOperators730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //&&-And Operator, ||-OR Operator, !-Not Operator

            int a = 5, b = 4;

            if(a > 5 && b < 5) 
            Console.WriteLine("a && b");

            if(a > 5 || b < 5)
            Console.WriteLine("a || b");

            if(!(a > 5 && b < 5))
            Console.WriteLine("!(a && b)");
        }
    }
}
