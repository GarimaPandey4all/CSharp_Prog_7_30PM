﻿using System;
using System.Collections.Generic;

namespace GenericsClass_730PM
{
    //Generic Class
    public class MyGeneric<T>
    {
        private T[] array; //Field

        public MyGeneric(int size){
            array = new T[size];
        }

        public T getItem(int index)
        {
            return array[index];
        }

        public void setItem(int index, T value)
        {
            array[index] = value;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Declare int array

            MyGeneric<int> intArray = new MyGeneric<int>(5);

            //Setting Values
            for(int i=0; i<5; i++)
            intArray.setItem(i, i*5);

            //Accessing values from an Array
            for(int i=0; i<5; i++)
            Console.Write(intArray.getItem(i) + "  ");

            Console.WriteLine();

            MyGeneric<char> charArray = new MyGeneric<char>(5);

            //Setting Values
            for(int i=0; i<5; i++)
            charArray.setItem(i, (char)(i+65));  // A= 65 to Z=90, a = 97 to z = 122

            //Accessing values from an Array
            for(int i=0; i<5; i++)
            Console.Write(charArray.getItem(i) + "  ");

            Console.WriteLine();

        }
    }
}
