﻿using System;
using System.Collections.Generic;

namespace GenericsMethod_730PM
{
    class Program
    {
        //Method/Function Generics
        static void Swap<T>(T a, T b)
        {
            Console.WriteLine("Before Swapping a={0} and b={1}", a, b);

            T temp;
            temp = a; 
            a = b;
            b = temp;  

            Console.WriteLine("After Swapping a={0} and b={1}", a, b);
        }

        static void Main(string[] args)
        {
            Swap(10, 20);
            Swap(23.5F, 45.6F);
        }
    }
}
