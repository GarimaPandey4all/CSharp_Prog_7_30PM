﻿using System;

namespace enum_2_730PM
{
    class Program
    {   
        enum Colors
        {
            red,
            yellow,
            blue,
            purple,
            gray
        }

        static void Main(string[] args)
        {
            Colors myColor = Colors.yellow;

            switch(myColor)
            {
                case Colors.red:
                Console.WriteLine("Red Color");
                break;

                case Colors.yellow:
                Console.WriteLine("Yellow Color");
                break;

                case Colors.blue:
                Console.WriteLine("Blue Color");
                break;

                case Colors.purple:
                Console.WriteLine("Purple Color");
                break;

                case Colors.gray:
                Console.WriteLine("Gray Color");
                break;

                default:
                Console.WriteLine("Invalid Case");
                break;
            }
        }
    }
}
