﻿using System;

namespace ArrayDays_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] days = {31, 29, 30, 31, 30, 31, 31, 30, 31, 31, 30, 31};

            for(int i=0; i<days.Length; i++)
            Console.WriteLine("Month {0} has {1} days.", i+1, days[i]);
        }
    }
}
