﻿using System;

namespace BitwiseOperators730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Bitwise &:"+(a & b));

            Console.WriteLine("Bitwise |:"+(a | b));

            Console.WriteLine("Bitwise ^:"+(a ^ b));

            Console.WriteLine("Bitwise <<:"+(a<<1));

            Console.WriteLine("Bitwise >>:"+(b>>1));
        }
    }
}
