﻿using System;

namespace AssignmentOperators730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int sum = 0;

            sum += a; // sum = sum + a;
            Console.WriteLine(sum);
            sum -= a;
            Console.WriteLine(sum);
            sum *= a;
            Console.WriteLine(sum);
            sum /= a;
            Console.WriteLine(sum);
            sum %= a;
            Console.WriteLine(sum);

            //sum &= a; //Bitwise And Operator
        }
    }
}
