﻿using System;

namespace ArithmeticOperators730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition is:"+(a+b));

            Console.WriteLine("Subtraction is:"+(a-b));

            Console.WriteLine("Multiplication is:"+(a*b));

            Console.WriteLine("Division is:"+(a/b));

            Console.WriteLine("Modulus is:"+(a%b)); // a = 3, b= 7 , 3

            Console.WriteLine("Pre-Increment is:"+(++a)); // a = 3, 4

            Console.WriteLine("Post-Increment is:"+(a++)); // a = 4

            Console.WriteLine(a); // a = 5

            Console.WriteLine("Pre-Decrement is:"+(--b)); // b = 7, b = 6

            Console.WriteLine("Post-Decrement is:"+(b--)); // b = 6

            Console.WriteLine(b); // b = 5
        }
    }
}
