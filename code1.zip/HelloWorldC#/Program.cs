﻿using System; 

namespace HelloWorldC_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Brain Mentors");
        }
    }
}
