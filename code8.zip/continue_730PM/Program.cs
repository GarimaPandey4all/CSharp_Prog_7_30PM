﻿using System;

namespace continue_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            for(i=1; i<=10; i++)
            {
                if(i == 5)
                {
                    continue; //Jump to next Iteration
                }
                Console.WriteLine(i);
            }
        }
    }
}
