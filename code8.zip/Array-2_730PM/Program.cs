﻿using System;

namespace Array_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = {"Brain", "C#", "Mentors"};

            arr[1] = "Development";

            for(int i=0; i<3; i++)
            Console.WriteLine(arr[i]);
        }
    }
}
