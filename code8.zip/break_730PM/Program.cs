﻿using System;

namespace break_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            for(i=1; i<=10; i++)
            {
                if(i == 8) // true
                {
                    break;
                }
                Console.WriteLine(i);
            }
            Console.WriteLine(i);
        }
    }
}
