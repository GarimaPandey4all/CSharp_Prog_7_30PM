﻿using System;

namespace forEachLoop_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array : foreach Loop

            int[] arr = {10, 20, 30, 40, 50};

            //foreach(type variableName in arrayName)
            foreach(int i in arr)
            Console.WriteLine(i);
        }
    }
}
