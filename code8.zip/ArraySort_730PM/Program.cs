﻿using System;

namespace ArraySort_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {50, 30, 20, 10, 40}; // Unsorted Array

            Array.Sort(arr);

            foreach(int i in arr)
            Console.WriteLine(i);

            for(int j=4; j>=0; j--)
            Console.WriteLine(arr[j]);
        }
    }
}
