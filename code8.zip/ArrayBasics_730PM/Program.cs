﻿using System;

namespace ArrayBasics_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr;

            //arr = {10, 20, 30}; // error

            arr = new int[] {10, 20, 30};

            foreach(int i in arr)
            Console.WriteLine(i);
        }
    }
}
