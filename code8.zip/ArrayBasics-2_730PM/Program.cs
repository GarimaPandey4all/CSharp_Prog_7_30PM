﻿using System;

namespace ArrayBasics_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            // User Input in Array
            int[] arr = new int[5];
            int i;

            Console.WriteLine("Enter values in an array:");
            for(i=0; i<arr.Length; i++)
            arr[i] = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Values in an array are:");
            for(i=0; i<arr.Length; i++)
            Console.WriteLine(arr[i]);
        }
    }
}
