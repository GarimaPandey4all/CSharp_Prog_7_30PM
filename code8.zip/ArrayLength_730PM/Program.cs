﻿using System;

namespace ArrayLength_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {1, 2, 3, 4, 5, 6};

            Console.WriteLine(arr.Length);

            for(int i=0; i<arr.Length; i++)
            Console.WriteLine(arr[i]);
        }
    }
}
