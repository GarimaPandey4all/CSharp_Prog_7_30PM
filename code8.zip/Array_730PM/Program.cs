﻿using System;

namespace Array_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array's Size = 5
            int[] a = {10, 20, 30, 40, 50}; // Array Declaration and Initialization

            //Access the values from the array - First Way
            Console.WriteLine(a[0]);
            Console.WriteLine(a[1]);
            Console.WriteLine(a[2]);
            Console.WriteLine(a[3]);
            Console.WriteLine(a[4]);

            Console.WriteLine("\n");

            //Access values from the array: Second Way
            for(int i=0; i<5; i++)
            Console.WriteLine(a[i]);
        }
    }
}
