﻿using System;

delegate int NumberChanger(int n);

namespace delegates_2_730PM
{
    class Program
    {
        static int num = 10;

        public static int Add(int a)
        {
            num += a; // 10 + 10 = 20
            return num; // 20
        }

        public static int Mul(int a)
        {
            num *= a; // num = 20 * 10
            return num; // 200
        }

        public static int display()
        {
            return num;
        }

        static void Main(string[] args)
        {
            NumberChanger obj;
            NumberChanger obj1 = new NumberChanger(Add);
            NumberChanger obj2 = new NumberChanger(Mul);

            obj = obj1;
            obj += obj2; // obj = obj + obj2; // obj = 20 + 200

            //Calling of Multicast
            obj(10);
            Console.WriteLine("Value of number is: "+display());  
        }
    }
}
