﻿using System;
using System.Collections;

namespace CollectionsStack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack sobj = new Stack();

            //Insert into a stack
            sobj.Push('A');
            sobj.Push('m');
            sobj.Push('i');
            sobj.Push('t');

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
                Console.Write(ch + " ");
            
            Console.WriteLine();

            Console.WriteLine("Top value of stack is: {0}", sobj.Peek());

            sobj.Pop();

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
                Console.Write(ch + " ");
            
            Console.WriteLine();

            sobj.Push('C');
            sobj.Push('#');

             Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
                Console.Write(ch + " ");
            
            Console.WriteLine();
            
        }
    }
}
