﻿using System;

namespace switchProgram730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c; 
            int number;

            Console.WriteLine("Press 1. Largest Number");
            Console.WriteLine("Press 2. Even Odd");
            Console.WriteLine("Press 3. X-OR");
            Console.WriteLine("Press 4. Swap Numbers");
            Console.WriteLine("Enter your choice:");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1:
                Console.WriteLine("Enter any number for a:");
                a = Convert.ToInt32(Console.ReadLine());
                
                Console.WriteLine("Enter any number for b:");
                b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter any number for c:");
                c = Convert.ToInt32(Console.ReadLine());

                int largest = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);

                Console.WriteLine("Largest number is:"+largest);
                break;

                case 2:
                Console.WriteLine("Enter any number:");
                number = Convert.ToInt32(Console.ReadLine());

                string text = ((number % 2) == 0) ? "Number is Even" : "Number is Odd";

                Console.WriteLine(text);
                break;

                case 3:
                Console.WriteLine("Enter any number for a:");
                a = Convert.ToInt32(Console.ReadLine());
                
                Console.WriteLine("Enter any number for b:");
                b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("X-OR is:"+(a ^ b));
                break;

                case 4:
                Console.WriteLine("Enter any number for a:");
                a = Convert.ToInt32(Console.ReadLine());
                
                Console.WriteLine("Enter any number for b:");
                b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Before swapping the value of a={0} and b={1}.", a, b);

                a = a ^ b;
                b = a ^ b;
                a = a ^ b;

                Console.WriteLine("After swapping the value of a={0} and b={1}.", a, b);
                break;

                default:
                Console.WriteLine("Invalid Choice");
                break;

            }
        }
    }
}
