﻿using System;

namespace forLoop_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i;

            Console.WriteLine("Enter any number that you want to print the table:");
            n = Convert.ToInt32(Console.ReadLine());

            for(i=1; i<=10; i++)
            Console.WriteLine("{0} * {1} = {2}", n, i, n * i);
        }
    }
}
