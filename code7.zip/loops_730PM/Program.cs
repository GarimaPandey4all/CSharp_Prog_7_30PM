﻿using System;

namespace loops_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Loop : Iteration/Repeatation
            //for, while and do-while 

            /*
                for(initialization; condition; increment/decrement)
                {
                    //loop body 
                }

                initialization;
                while(condition)
                {
                    while loop body section
                    increment/decrement;
                }

                initialization;
                do
                {
                    do-while loop body section
                    increment/decrement;
                }while(condition);
            
            */

            for(int i=1; i<=5; i++)
            Console.WriteLine("Hello World!");
        }
    }
}
