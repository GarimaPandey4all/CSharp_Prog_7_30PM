using System;

namespace Inheritance_730PM
{   
    //Child : Derived Class
    class Child : Parent // Inheritance
    {
        public int id_Child = 120;

        public void showData()
        {
            Console.WriteLine("This is Child Class");
        }
    }
}
