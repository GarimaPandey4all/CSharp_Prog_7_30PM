using System;

namespace Inheritance_730PM
{   
    //Parent : Base Class
    class Parent
    {
        public int id_Parent = 101;

        public void display()
        {
            Console.WriteLine("This is Parent Class");
        }
    }
}
