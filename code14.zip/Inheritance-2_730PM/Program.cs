﻿using System;

namespace Inheritance_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();

            obj.display();
            obj.showData();
        }
    }
}
