using System;

namespace Inheritance_2_730PM
{
    class Car : Vehicle
    {
        public void display()
        {
            Console.WriteLine("This is Child");
        }
    }
}
