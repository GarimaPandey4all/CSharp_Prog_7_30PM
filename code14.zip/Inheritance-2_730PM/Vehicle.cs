using System;

namespace Inheritance_2_730PM
{
    //Sealed Class
    //sealed class Vehicle
    class Vehicle
    {
        public void showData()
        {
            Console.WriteLine("This is Parent");
        }
    }
}
