﻿using System;

namespace settergetterProperties_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();
            obj.Name = "Brain Mentors";
            Console.WriteLine(obj.Name);
        }
    }
}
