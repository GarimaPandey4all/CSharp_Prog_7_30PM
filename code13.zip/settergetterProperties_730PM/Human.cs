using System;

namespace settergetterProperties_730PM
{
    class Human
    {
        //private string name; // field

        //Property
        public string Name
        {
        
            // get {
            //     return name;
            // }

            // set {
            //     name = value;
            // }

            get;
            set;
            
        }
    }
}
