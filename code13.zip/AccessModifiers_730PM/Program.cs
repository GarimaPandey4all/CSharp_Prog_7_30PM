﻿using System;

namespace AccessModifiers_730PM
{
    //Access Modifiers: Private (By Default), Public, Protected, Internal

    class Program
    {
        static void Main(string[] args)
        {
            HelloWorld obj = new HelloWorld();
            Console.WriteLine(obj.text);            
        }
    }
}
