using System;

namespace AccessModifiers_730PM
{
    //Access Modifiers: Private (By Default), Public, Protected, Internal

    class HelloWorld
    {
        public string text = "Hello World";
    }
}
