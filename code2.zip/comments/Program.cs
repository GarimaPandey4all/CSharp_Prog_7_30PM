﻿using System;

namespace comments
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // -- Single Line Comment

            /*
                Name : Brain Mentors
                Date: 23-07-2020
                C#
            */           
        }
    }
}
