﻿using System;

namespace variables_
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables : are containers for storing values/data.

            int a; // integer value storage // Only declaration

            a = 10; // Initialization/Assignment

            Console.WriteLine("a is:" +a); // ; - terminate the particular statement

            a = 30; // vary - override

            Console.WriteLine(a);

            //constant variable : const : fixed value
            const int b = 20;

            //b = 50; // error

            Console.WriteLine(b);

            double c = 40.9D;
            Console.WriteLine(c);

            char ch = 'A';
            Console.WriteLine(ch);

            string text = "Brain";
            Console.WriteLine(text);

        }
    }
}
