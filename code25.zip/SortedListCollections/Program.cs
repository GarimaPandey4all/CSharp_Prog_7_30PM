﻿using System;
using System.Collections;

namespace SortedListCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sorted List: It is a combination of ArrayList(Access by index value) and Hashtable(Access by key-value pair).
            //It is always access the values in an ascending order.

            SortedList obj = new SortedList();

            //Insert into a Sorted List 

            obj.Add("500", "Rishi");
            obj.Add("400", "Brain");
            obj.Add("200", "Dilip");
            obj.Add("100", "Rahul");
            obj.Add("050", "Amit");

            if(obj.ContainsValue("Mentors"))
            Console.WriteLine("Already Available");
            else
            obj.Add("450", "Mentors");

            ICollection key = obj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + " : " + obj[str]);
        }
    }
}
