﻿using System;

namespace function_4_730PM
{
    class Program
    {
        //4. Without function parameters and with return type
        static int Sum()
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a+b);

            return 0;
        }
        static void Main(string[] args)
        {
            Sum();
        }
    }
}
