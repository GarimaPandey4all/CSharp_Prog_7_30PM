﻿using System;

namespace function_3_730PM
{   
    //3. With function parameters and with return type
    class Program
    {
        static int Sum(int a, int b)
        {
            Console.WriteLine(a+b);
            //return (a+b);
            return 0;
        }

        static void Main(string[] args)
        {
            //int sum = Sum(10, 20);
            //Console.WriteLine(sum);
            Sum(10, 20);
        }
    }
}
