﻿using System;

namespace function_730PM
{
    class Program
    {   //1. Without function parameter and without return type
        //return_type function_name(){}
        static void HelloWorld() // function definition
        {
            //Code Block
            Console.WriteLine("Hello World");
        }

        static void Main(string[] args)
        {
            //function calling
            HelloWorld(); 
            HelloWorld(); 
            HelloWorld(); 
            HelloWorld(); 
            HelloWorld(); 
            HelloWorld(); 
        }
    }
}
