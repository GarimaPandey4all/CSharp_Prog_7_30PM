﻿using System;

namespace JaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[][] arr = new int[2][] {new int[]{1, 2, 3, 4, 5}, new int[]{10, 20, 30}};
            int[][] arr = new int[2][];
            int i, j;

            // arr[0] new int[5];
            // arr[1] new int[3];

            arr[0] = new int[]{1, 2, 3, 4, 5};
            arr[1] = new int[]{10, 20, 30};

            for(i=0; i<arr.Length; i++)
            {
                for(j=0; j<arr[i].Length; j++)
                {
                    Console.Write("{0}\t", arr[i][j]);
                }
                Console.WriteLine();
            }
        }
    }
}
