﻿using System;

namespace function_2_730PM
{
    class Program
    {   //2. With function parameter and without return type
        static void Sum(int a, int b) // a, b: function parameters
        {
            Console.WriteLine("Addition is:"+(a+b));
        }

        static void Main(string[] args)
        {
            Sum(10, 20); // 10, 20: function arguments
            Sum(50, 20);
        }
    }
}
