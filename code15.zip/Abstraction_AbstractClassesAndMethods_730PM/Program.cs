﻿using System;

namespace Abstraction_AbstractClassesAndMethods_730PM
{
    //Abstract Class
    abstract class Animal
    {   
        //Abstract Method/Function
        public abstract void animalSound(); // Abstarct method does not have a body or definition.

        //Normal Method
        public void animalLeg()
        {
            Console.WriteLine("Animaal Legs");
        }
    }

    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog says..bhau bhau");
        }
    }

    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat says..meou meou");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Animal obj = new Animal(); // error
            Dog obj = new Dog();
            obj.animalSound();
            obj.animalLeg();

            Cat obj1 = new Cat();
            obj1.animalSound();
            obj1.animalLeg();
        }
    }
}
