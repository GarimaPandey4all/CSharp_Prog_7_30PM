﻿using System;

namespace Polymorphism_730PM
{   //Base Class
    class Animal
    {
        public virtual void animalSound()
        {
            Console.WriteLine("Animal Sound");
        }
    }

    //Derived Class
    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog Says... bhau bhau");
        }
    }

    //Derived Class
    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat says... meou meou");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Animal obj = new Animal(); // Parent class object
            Animal obj1 = new Dog(); // Child/Dog class object
            Animal obj2 = new Cat(); // Child/Cat class object

            obj.animalSound();
            obj1.animalSound();
            obj2.animalSound();
        }
    }
}
