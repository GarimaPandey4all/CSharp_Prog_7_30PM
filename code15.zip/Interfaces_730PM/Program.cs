﻿using System;

namespace ProgramsAnother
{
    /*
        Interface: An interface is completeley abstarct class which can only contain abstract method/functions and properties.
        By default, In interface the members of an interface are public and abstract.
    */

    //Interface : abstarct class
    interface Animal
    {
        void animalSound(); // Only Declare // Because it is abstarct method by default.
    }

    class Dog : Animal
    {
        public void animalSound()
        {
            Console.WriteLine("Dog Says.. bhau bhau");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Dog obj = new Dog();
            obj.animalSound();
        }
    }
}
