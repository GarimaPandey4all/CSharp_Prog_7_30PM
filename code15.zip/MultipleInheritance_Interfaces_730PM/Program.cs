﻿using System;

namespace MultipleInheritance_Interfaces_730PM
{
    interface firstInterface
    {
        void display();
    }

    interface secondInterface
    {
        void showData();
    }

    class Child : firstInterface, secondInterface
    {
        public void display()
        {
            Console.WriteLine("It is First Interface");
        }

        public void showData()
        {
            Console.WriteLine("It is Second Interface");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Child obj = new Child();
            obj.display();
            obj.showData();
        }
    }
}
