﻿using System;
using System.Collections;

namespace CollectionsQueue_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue obj = new Queue();

            //Insert in a Queue

            obj.Enqueue('A');
            obj.Enqueue('m');
            obj.Enqueue('i');
            obj.Enqueue('t');

            Console.WriteLine("Queue is:");
            foreach(char ch in obj)
            Console.Write(ch + "  ");

            Console.WriteLine();

            //Delete/Remove from the queue

            Console.WriteLine("Remove values from the queue:");
            char character = (char)obj.Dequeue();
            Console.WriteLine("Removed value is:"+character);

            character = (char)obj.Dequeue();
            Console.WriteLine("Removed value is:"+character);

            obj.Enqueue('B');

            Console.WriteLine("Queue is:");
            foreach(char ch in obj)
            Console.Write(ch + "  ");

            Console.WriteLine();           
        }
    }
}
