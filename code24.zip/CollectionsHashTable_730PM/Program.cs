﻿using System;
using System.Collections;

namespace CollectionsHashTable_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable obj = new Hashtable();

            //Insert in a hashtable

            obj.Add("100", "Rishi");
            obj.Add("101", "Tanya");
            obj.Add("102", "Amit");
            obj.Add("103", "Rahul");
            obj.Add("104", "Dilip");

            if(obj.ContainsValue("Shivam"))
                Console.WriteLine("He is already in a hashtable.");
            else
            obj.Add("105", "Dilip");

            //Get a Collection of Keys
            ICollection key = obj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + " : " + obj[str]);
        }
    }
}
