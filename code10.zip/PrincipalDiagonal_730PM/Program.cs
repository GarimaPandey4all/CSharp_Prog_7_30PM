﻿using System;

namespace PrincipalDiagonal_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3, 3];
            int i, j;

            Console.WriteLine("Enter values in a Matrix:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in a Matrix are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine("\n");
            }

            Console.WriteLine("Principal Diagonal is:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    if(i == j)
                    Console.Write("{0}\t", matrix[i, j]);
                }
            }
        }
    }
}
