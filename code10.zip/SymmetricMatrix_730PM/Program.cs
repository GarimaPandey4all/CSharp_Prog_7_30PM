﻿using System;

namespace SymmetricMatrix_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3, 3];
            int[,] temp = new int[3, 3];
            int i, j;
            int count = 1; //indicate that given matrix is Symmetric Matrix

            Console.WriteLine("Enter values in a Matrix:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in a Matrix are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine("\n");
            }

            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    temp[j, i] = matrix[i, j];
                }
            }

            Console.WriteLine("Transpose Matrix is:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", temp[i, j]);
                }
                Console.WriteLine("\n");
            }

            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    if(matrix[i, j] != temp[i, j])
                    {
                        count++;
                        break;
                    }
                }
            }

            if(count == 1)
                Console.WriteLine("Symmetric Matrix");
            else
                Console.WriteLine("Not a Symmetric Matrix");
        }
    }
}
