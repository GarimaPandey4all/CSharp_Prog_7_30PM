﻿using System;

namespace Table_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] table = new string[2, 3];
            int i, j;

            Console.WriteLine("Enter your books into the table:");
            for(i=0; i<2; i++)
            {
                for(j=0; j<3; j++)
                {
                    table[i, j] = Console.ReadLine();
                }
            }

            Console.WriteLine("Books into the table are:");
            for(i=0; i<2; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", table[i, j]);
                }
                Console.WriteLine("\n");
            }
        }
    }
}
