﻿using System;

namespace _3DArray_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,,] arr = new string[2, 2, 2];
            int i, j, k;

            Console.WriteLine("Enter your data into the array:");
            for(i=0; i<2; i++)
            {
                for(j=0; j<2; j++)
                {
                    for(k=0; k<2; k++)
                    arr[i, j, k] = Console.ReadLine();
                }
            }

            Console.WriteLine("Data into the array are:");
            for(i=0; i<2; i++)
            {
                for(j=0; j<2; j++)
                {
                    for(k=0; k<2; k++)
                    Console.Write("{0}\t", arr[i, j, k]);
                }
            }
        }
    }
}
