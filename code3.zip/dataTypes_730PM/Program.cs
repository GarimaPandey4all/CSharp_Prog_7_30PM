﻿using System;

namespace dataTypes_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 10; // 4 bytes = 4 * 8 bits = 32 bits // Interger
            long num1 = 20L; // 8 bytes = 64 bits // Interger

            float floatNum = 45.78F; // 4 bytes // Floating Point Number
            double doubleNum = 23.60D; // 8 bytes // Floating Point Number 

            char ch = 'A'; // 2 bytes // Character

            string myText = "Brain Mentors"; // 2 bytes per character // String

            bool state = true; // 1 bit, true - 1, false - 0

            Console.WriteLine(num);
            Console.WriteLine(num1);

            Console.WriteLine(floatNum);
            Console.WriteLine(doubleNum);

            Console.WriteLine(ch);

            Console.WriteLine(myText);

            Console.WriteLine(state);

        }
    }
}
