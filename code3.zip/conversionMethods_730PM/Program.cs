﻿using System;

namespace conversionMethods_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //int intNum = 10;
            //Console.WriteLine(Convert.ToDouble(intNum));
            //Console.WriteLine(Convert.ToString(intNum));

            Console.WriteLine("Enter any value:");
            int intNum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(intNum);

            Console.WriteLine("Enter any value:");
            double doubleNum = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(doubleNum);

            Console.WriteLine("Enter any value:");
            long longNum = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine(longNum);

            Console.WriteLine("Enter any value:");
            bool state = Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine(state);
            
        }
    }
}
