﻿using System;

namespace typeCasting_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Implicit Type Conversion
            int num = 20;
            long mynum = num; 

            Console.WriteLine(num);
            Console.WriteLine(mynum);

            //Explicit Type Conversion
           double doubleNum = 45.8D;
           int intNum = (int) doubleNum;

            Console.WriteLine(doubleNum);
            Console.WriteLine(intNum);

        }
    }
}
