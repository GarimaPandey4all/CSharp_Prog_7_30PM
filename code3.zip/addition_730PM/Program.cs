﻿using System;

namespace addition_730PM
{
    class Program
    {
        static void Main(string[] args)
        {   
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine()); // User Input Read //Type Conversion

            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine()); 

            //Console.WriteLine("Addition of two numbers is:" +(a+b));

            Console.WriteLine("Addition of {0} and {1} is: {2}", a, b, (a+b));
        }
    }
}
