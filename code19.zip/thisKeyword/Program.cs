﻿using System;

namespace thisKeyword
{
    class Add
    {
        public int a, b;

        public Add(int a, int b)
        {
            this.a = a;
            this.b = b;
        }

        public void display()
        {
            Console.WriteLine("Addition is:"+(a+b));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Add obj = new Add(10, 20);

            obj.display();
        }
    }
}
