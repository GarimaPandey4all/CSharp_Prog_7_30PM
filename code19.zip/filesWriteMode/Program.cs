﻿using System;
using System.IO;

namespace filesWriteMode
{
    class Program
    {
        static void Main(string[] args)
        {
            //The file class from the System.IO namespace, allows us to work with files.
            string writeText = "Hello, How are you?";
            File.WriteAllText("Test.txt", writeText);

            Console.WriteLine("Content Inserted in a File Successfully");
        }
    }
}
