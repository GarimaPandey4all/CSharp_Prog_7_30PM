﻿using System;
using System.IO;

namespace filesReadMode
{
    class Program
    {
        static void Main(string[] args)
        {
            string readText = File.ReadAllText("test.txt"); // Read content from a file
            Console.WriteLine(readText);
        }
    }
}
