﻿using System;
using System.IO;

namespace filesCreateOpenAppend
{
    class Program
    {
        static void Main(string[] args)
        {
            string myFile = @"test.txt";

            using(StreamWriter writeText = File.CreateText(myFile))
            {
                writeText.WriteLine("Hello!");
                writeText.WriteLine("Welcome to Brain Mentors");
            }

            using(StreamWriter writeText = File.AppendText(myFile))
            {
                writeText.WriteLine("How are you?");
            }

            using(StreamReader Text = File.OpenText(myFile))
            {
                string readText = "";
                while((readText = Text.ReadLine()) != null)
                {
                    Console.WriteLine(readText);
                }
            }
        }
    }
}
