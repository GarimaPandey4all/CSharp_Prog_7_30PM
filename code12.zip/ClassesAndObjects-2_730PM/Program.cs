﻿using System;

namespace ClassesAndObjects_2_730PM
{
    class Car
    {
        string color;
        string model;
        int year;
    
        static void Main(string[] args)
        {
            Car MarutiSuzuki  = new Car();
            Car Honda  = new Car();

            MarutiSuzuki.color = "red";
            MarutiSuzuki.model = "M5";
            MarutiSuzuki.year = 2019;

            Console.WriteLine( MarutiSuzuki.color);
            Console.WriteLine( MarutiSuzuki.model);
            Console.WriteLine( MarutiSuzuki.year);

            Honda.color = "red";
            Honda.model = "H3";
            Honda.year = 2020;

            Console.WriteLine( Honda.color);
            Console.WriteLine( Honda.model);
            Console.WriteLine( Honda.year);
        }
    }
}
