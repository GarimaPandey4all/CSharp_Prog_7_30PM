﻿using System;

namespace Constructor_730PM
{
    class Human
    {
        string name;
        int age;
        
        //Constructor: Special Method: Class name and constructor name both must be the same
        //Constructor is called whne the object of the class created.
        //It can't have any return type like void, int etc
        Human()
        {
            name = "Amit";
            age = 25;
        }

        static void Main(string[] args)
        {
            Human Amit = new Human();
            Console.WriteLine(Amit.name);
            Console.WriteLine(Amit.age);
        }
    }
}
