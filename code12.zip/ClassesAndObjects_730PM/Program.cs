﻿using System;

namespace ClassesAndObjects_730PM
{
    //DRY: Don't Repeat Yourself

    class HelloWorld
    {
        //Class Members

        //Data Member/ Field
        string text = "Hello World";

        //Member function/Method
        void showData()
        {
            Console.WriteLine(text);
        }

        static void Main(string[] args)
        {
            //Create Class's Object
            HelloWorld obj = new HelloWorld();
            HelloWorld obj1 = new HelloWorld(); 
            obj.showData();
            obj1.showData();
        }
    }
}
