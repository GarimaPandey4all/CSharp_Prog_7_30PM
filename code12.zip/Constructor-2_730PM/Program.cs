﻿using System;

namespace Constructor_2_730PM
{
    class Human
    {
        string name;
        int age;

        Human(string personName, int personAge)
        {
            name = personName;
            age = personAge;
        }

        static void Main(string[] args)
        {
            Human Amit = new Human("Amit", 25);
            Console.WriteLine(Amit.name + " " + Amit.age);
        }
    }
}
