﻿using System;
using System.Collections;

namespace CollectionClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            //Collection Classes are specialized classes for data storage and retrieval. These classes support stack, arrays, linked list and hashtables. 

            //1. ArrayList: It is an alternative to an array, Arraylist resizes itself automatically. It allows dynamic memory allocation.

            ArrayList al = new ArrayList();

            Console.WriteLine("Insertion in Array:");
            al.Add(10);
            al.Add(20);
            al.Add(30);
            al.Add(40);
            al.Add(50);

            Console.WriteLine("Count is: {0}", al.Count);
            Console.WriteLine("Capacity is: {0}", al.Capacity);  

            Console.WriteLine("Values in Array are:");
            foreach(int i in al)
            Console.Write(i + " ");
            Console.WriteLine();
        }
    }
}
