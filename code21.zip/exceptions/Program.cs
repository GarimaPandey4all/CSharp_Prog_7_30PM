﻿using System;

namespace exceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exceptions: 

            /*
                try and catch:

                try: The try statement allows you to declarea block of code to be tested for errors while it is being executed.

                catch: The catch statement allows you to define a block of code to be executed, if an error occurs in the try block.

                try
                {

                }
                catch (Exception e)
                {

                }
            */

            try {
                int[] digits = {10, 20, 30, 40, 50};
                Console.WriteLine(digits[6]);
            }

            catch (Exception e){
                //Console.WriteLine(e.Message);
                Console.WriteLine("Index out of Range");
            }
        }
    }
}
