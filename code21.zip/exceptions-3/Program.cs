﻿using System;

namespace exceptions_3
{
    class Program
    {
        static void findAge(int age)
        {
            if(age < 20)
            throw new ArithmeticException("Not Matched with the Age limit.");

            else
            Console.WriteLine("Matched with the Age limit.");

        }

        static void Main(string[] args)
        {
            //throw: The throw statement allows you to create a custom error.
            /*
                Predefined Exceptions Classes in C#:
                1. ArithmeticException
                2. IndexOutofRangeException
                3. FileNotFoundException
                4. TimeOutException
            */

            findAge(18);

        }
    }
}
