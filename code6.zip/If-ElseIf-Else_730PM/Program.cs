﻿using System;

namespace If_ElseIf_Else_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //WAP to find the grade of a student.

            int english, hindi, maths, GK, science;

            Console.WriteLine("Enter Marks:");
            english = Convert.ToInt32(Console.ReadLine());
            hindi = Convert.ToInt32(Console.ReadLine());
            maths = Convert.ToInt32(Console.ReadLine());
            GK = Convert.ToInt32(Console.ReadLine());
            science = Convert.ToInt32(Console.ReadLine());

            int sum = english + hindi + maths + GK + science;

            Console.WriteLine("Total Marks:"+sum);

            int percentage = sum / 5;

            Console.WriteLine("Percenatge is:{0}%",percentage);

            if(percentage >= 50 && percentage <= 60)
            Console.WriteLine("Grade D");

            else if(percentage >= 60 && percentage <= 70)
            Console.WriteLine("Grade C");

            else if(percentage >= 70 && percentage <= 80)
            Console.WriteLine("Grade B");

            else if (percentage >= 80 && percentage <= 100)
            Console.WriteLine("Grade A");

            else 
            Console.WriteLine("You are Fail...");
        }
    }
}
