﻿using System;

namespace TernaryOperator_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a , b, c;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for c:");
            c = Convert.ToInt32(Console.ReadLine());
            
            int largest = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);

            Console.WriteLine("Largest number is:" +largest);
        }
    }
}
