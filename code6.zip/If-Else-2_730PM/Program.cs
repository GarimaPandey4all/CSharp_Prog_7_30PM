﻿using System;

namespace If_Else_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Find largest number between two given numbers.

            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            if(a > b)
            Console.WriteLine("a is largest");
            else
            Console.WriteLine("b is largest");
        }
    }
}
