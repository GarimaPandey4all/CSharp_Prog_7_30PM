﻿using System;

namespace string_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Hello World"; // string indexing start with 0 position
            //Console.WriteLine(text.IndexOf("W"));
            Console.WriteLine(text[6]);

            int position = text.IndexOf("W");
            string subString = text.Substring(position);
            Console.WriteLine(subString);

            //Escape Characters

            string myText = "My Full Name is \"Brain\" Mentors";
            Console.WriteLine(myText);

            string myText2 = "My Full Name is \'Brain\' Mentors";
            Console.WriteLine(myText2);

            string myText3 = "Escape Character Backslash \\";
            Console.WriteLine(myText3);

            string myText4 = "Escape Character \nBackslash \\"; // \n - New Line
            Console.WriteLine(myText4);

            string myText5 = "Escape Character\tBackslash \\"; // \t - Tab
            Console.WriteLine(myText5);

            string myText6 = "Escape Character Backslash:\b "; // \b - Backspace
            Console.WriteLine(myText6);
        }
    }
}
