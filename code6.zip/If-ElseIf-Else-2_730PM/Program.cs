﻿using System;

namespace If_ElseIf_Else_2_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Find Largest number between given three numbers.

            int a , b, c;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for c:");
            c = Convert.ToInt32(Console.ReadLine());
            Console.Write("Largest is:");
            
            if(a > b && a > c)
            Console.WriteLine(a);
            else if(b > c)
            Console.WriteLine(b);
            else
            Console.WriteLine(c);

        }
    }
}
