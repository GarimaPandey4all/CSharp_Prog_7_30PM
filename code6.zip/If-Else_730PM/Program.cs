﻿using System;

namespace If_Else_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Even-Odd Program

            int number;

            Console.WriteLine("Enter any number:");
            number = Convert.ToInt32(Console.ReadLine());

            int remainder = number % 2;

            if(remainder == 0) // true
            Console.WriteLine("Number is Even");
            else // optional block
            Console.WriteLine("Number is Odd");
        }
    }
}
