﻿using System;

namespace TernaryOperator_730PM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Even-Odd
            int number;

            Console.WriteLine("Enter any number");
            number = Convert.ToInt32(Console.ReadLine());

            //Ternary Operator- ? : // Short hand of If-Else
            //(condition) ? True Statement : False Statement;
            //Expression-1 ? Expression-2 : Expression-3

            string text = ((number%2) == 0) ? "Number is Even" : "Number is Odd";
            Console.WriteLine(text);
        }
    }
}
